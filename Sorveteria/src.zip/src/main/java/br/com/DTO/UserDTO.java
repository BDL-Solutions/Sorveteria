package br.com.DTO;

public class UserDTO {
	private int id_user;
	private String nome_user;
	private String email_user;

	// Construtores, getters e setters



    // Getters e Setters

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id) {
        this.id_user = id;
    }

    public String getNome_user() {
        return nome_user;
    }

    public void setNome_user(String nome) {
        this.nome_user = nome;
    }

    public String getEmail_user() {
        return nome_user;
    }

    public void setEmail_user(String email) {
        this.email_user = email;
    }

}
